#Script to load the arterial network data from CSV files and represent it as a structured data class:
import csv
import os
from dataclasses import dataclass
#dataclasses is a lib that allows us to create classes that are used to store data without having to write,
#a bounch of code to init the class, so basically automates __init__ and other mdethods.
from pathlib import Path 
#This in adjection to os.path provides a way to handle file paths so there is no compatibility issues

@dataclass
class ArterialNetwork:
    points: list #coronary.ptxyz.csv
    branches: list #coronary.elems.csv
    branch_radii: list #coronary.elrad.csv
    branch_tree: list #coronary.eltre.csv
    inlet_points: list #coronary.bcinl.csv
    outlet_points: list #coronary.bcout.csv
    occluded_branches: list #coronary.occlu.csv
    graft_options: list #coronary.graft.csv (start point, end point, radius)
    n_points: int #number of points in the network
    n_branches: int #number of branches in the network
    data_path: Path #directory where the data files are loaded from

#Loading the data from the csv file, and converting into appropriate data structures. 
def data_dir(data_path=None):
    if data_path is None:
        return (Path(__file__).resolve().parent.parent / "data").resolve()
    return Path(os.fspath(data_path)).expanduser().resolve()

#Reading the rows from the csv file & stripping whitespaces.
def read_rows(path):
    rows = [] #list of rows, where each row is a list of strings
    
    with path.open(newline="") as handle:
        reader = csv.reader(handle)
        for row_number, row in enumerate(reader, start=1):
            rows.append([cell.strip() for cell in row])
    return rows

#Loading the data from the csv file, and converting into appropriate data structures!
def load_float_matrix(path, expected_cols):
    rows = read_rows(path)
    matrix = []
    for row_number, row in enumerate(rows, start=1):
        if len(row) != expected_cols:
            raise ValueError(
                f"{path.name}: Expected {expected_cols} columns, found {len(row)} at line {row_number}"
            )
        else:
            matrix.append(tuple(float(value) for value in row))
    return matrix

def load_vector(path):
    rows = read_rows(path)
    values = []
    for row_number, row in enumerate(rows, start=1):
        value = int(row[0])
        values.append(value)
    return values

#Loading the data from the csv file, and converting into appropriate data structures (:
#expects a matrix of integers, and checks # of col and data types
def load_matrix_int(path, expected_cols):
    rows = read_rows(path)

    matrix = [] #list of rows, where each row is a tuple (int, int) of integers, representing the connectivity of the branches

    #for loop to iterate through the rows of the csv file, and convert each value to an int
    for row_number, row in enumerate(rows, start=1):
        matrix.append(tuple(int(value) for value in row))
    return matrix

#Converts 1-based indices from the CSV file (bc MATLAB uses 1-based indx) to 0-based indices in Python
def _to_zero_based(values, name, upper_bound=None):

    normalized = [] #list of ints, where each int is the corresponding value from the input list
    
    #for loop to iterate through the values, and convert each value to an int.
    for index, value in enumerate(values, start=1):
        normalized.append(value - 1)
    return normalized

#Main function to load the arterial network data from the csv files and represent it as a structured data class
def load_arterial_network(data_path=None):
    resolved_data_dir = data_dir(data_path)
    #file paths and names 
    points_path = resolved_data_dir / "coronary.ptxyz.csv"
    branches_path = resolved_data_dir / "coronary.elems.csv"
    radii_path = resolved_data_dir / "coronary.elrad.csv"
    tree_path = resolved_data_dir / "coronary.eltre.csv"
    inlet_path = resolved_data_dir / "coronary.bcinl.csv"
    outlet_path = resolved_data_dir / "coronary.bcout.csv"
    occlusion_path = resolved_data_dir / "coronary.occlu.csv"
    graft_path = resolved_data_dir / "coronary.graft.csv"

    #using helper function (load_float_matrix, load_vector, load_matrix_int) to read the data from the csv files and convert it into appropriate data structures!
    raw_points = load_float_matrix(points_path, expected_cols=3) #coronary.ptxyz.csv: containing the x,y,z coordinates of each point
    raw_branches = load_matrix_int(branches_path, expected_cols=2) #cornary.elems.csv: define the connectivity of the arterial network
    raw_radii_rows = load_float_matrix(radii_path, expected_cols=1) #coronary.elrad.csv: contains the raidi of each branchin the network
    raw_tree = load_vector(tree_path) #coronary.eltre.csv: defines the hirarchy of the branches in the network
    raw_inlets = load_vector(inlet_path) #coronary.bincl.csv: lists the points that serve as the inlet (blood in)
    raw_outlets = load_vector(outlet_path) #coronary.bcout.csv: lists the points that serve as the outlet (blood out)
    raw_occlusions = load_vector(occlusion_path) #coronary.occlu.csv: identifies which branches are occluded (blocked)
    raw_grafts = load_float_matrix(graft_path, expected_cols=3) #coronary.graft.csv: lists potential grafting options, row: start point, column: end point, radius of the graft

    #Calculating the number of points and branches in the network based on the loaded data.
    n_points = len(raw_points)
    n_branches = len(raw_branches)
    branch_radii = [row[0] for row in raw_radii_rows] #radius values: first column of the elrad matrix

    branches = [] #branch connectivity: pairs of point indices that define each branch

    #for loop to iterate through the rows of the branch connectivity csv file, and convert each value to an int, and also 1-based indices to 0-based indice
    for row_number, (start, end) in enumerate(raw_branches, start=1):
        zero_based_pair = _to_zero_based(
            [start, end],
            f"{branches_path.name}: branch endpoints at row {row_number}",
            n_points,
        )
        branches.append((zero_based_pair[0], zero_based_pair[1]))
        
    #Converting the 1-based indices from the CSV files to 0-based indices for Python
    inlet_points = _to_zero_based(raw_inlets, inlet_path.name, n_points)
    outlet_points = _to_zero_based(raw_outlets, outlet_path.name, n_points)
    occluded_branches = _to_zero_based(
        raw_occlusions, occlusion_path.name, n_branches
    )
    #Graft Options: list of tuples containing the start point indx, and end point indx, 
    #side note: a tuple is an immutable sequence of values, example: (1,2,3) is a tuple of three integers.
    graft_options = []
    
    #for loop to iterate through the rows of the graft options and convert the start and end points to 0-based indices
    for row_number, row in enumerate(raw_grafts, start=1):
        start = int(row[0])
        end = int(row[1])
        radius = row[2]
        zero_based_pair = _to_zero_based(
            [start, end],
            f"{graft_path.name}: graft nodes at row {row_number}",
            n_points,
        )
        graft_options.append((zero_based_pair[0], zero_based_pair[1], radius))

    points = [(x, y, z) for x, y, z in raw_points] #points coordinates
    branch_tree = list(raw_tree) #branch hierarchy: list of integers where each value indicates the parent branch index (or -1 for root branches)

    return ArterialNetwork(
        points=points,
        branches=branches,
        branch_radii=branch_radii,
        branch_tree=branch_tree,
        inlet_points=inlet_points,
        outlet_points=outlet_points,
        occluded_branches=occluded_branches,
        graft_options=graft_options,
        n_points=n_points,
        n_branches=n_branches,
        data_path=resolved_data_dir,
    )
#Tests the loading function by running the script directly. 
if __name__ == "__main__":
    network = load_arterial_network()
    print(
        f"\nLoaded arterial network from {network.data_path} with {network.n_points} points and {network.n_branches} branches.\n")